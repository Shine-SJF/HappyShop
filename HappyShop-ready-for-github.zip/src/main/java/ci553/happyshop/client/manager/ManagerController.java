package ci553.happyshop.client.manager;

/**
 * Manager client Controller.
 * Routes UI actions to the Model.
 */
public class ManagerController {

    public ManagerModel model;

    public void handle(String action) {
        if (model == null) return;

        switch (action) {
            case "Refresh" -> model.refreshStats();
            case "Export" -> model.exportReport();
            case "Shutdown" -> model.shutdownSystem();
            case "SelectCollected" -> model.showSelectedCollectedDetail();
            default -> { /* ignore */ }
        }
    }
}