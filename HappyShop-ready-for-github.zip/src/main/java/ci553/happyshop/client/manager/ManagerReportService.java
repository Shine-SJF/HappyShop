package ci553.happyshop.client.manager;

import ci553.happyshop.utility.StorageLocation;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * File-based reporting service used by the Manager client.
 *
 * Computes:
 *  - Count of orders by state (based on file presence)
 *  - Total sales (sum of Total price lines in collected order files)
 *  - A recent collected orders list (latest modified first)
 *
 * Exports a simple CSV report for evidence / audit.
 */
public class ManagerReportService {

    private static final Pattern TOTAL_PRICE_PATTERN = Pattern.compile("^Total\\s+price:\\s*£?([0-9]+(?:\\.[0-9]{1,2})?)\\s*$");
    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    public ManagerStats computeStats() throws IOException {
        ensureOrderFoldersExist();

        int orderedCount = countTxtFiles(StorageLocation.orderedPath);
        int progressingCount = countTxtFiles(StorageLocation.progressingPath);
        int collectedCount = countTxtFiles(StorageLocation.collectedPath);

        double totalSales = sumCollectedSales(StorageLocation.collectedPath);

        List<String> recentCollected = listRecentCollected(StorageLocation.collectedPath, 20);

        return new ManagerStats(
                orderedCount,
                progressingCount,
                collectedCount,
                totalSales,
                LocalDateTime.now(),
                recentCollected
        );
    }

    public Path exportCsvReport(ManagerStats stats, Path reportsDir) throws IOException {
        String fileName = "manager_report_" + stats.lastUpdated().format(FILE_TS) + ".csv";
        Path out = reportsDir.resolve(fileName);

        List<String> lines = new ArrayList<>();
        lines.add("generated_at,ordered,progressing,collected,total_sales_gbp");
        lines.add(String.format("%s,%d,%d,%d,%.2f",
                stats.lastUpdated(),
                stats.orderedCount(),
                stats.progressingCount(),
                stats.collectedCount(),
                stats.totalSales()
        ));
        lines.add("");
        lines.add("recent_collected_order_files");
        for (String r : stats.recentCollectedOrderIds()) {
            lines.add(r.replace(',', ';'));
        }

        Files.write(out, lines, StandardCharsets.UTF_8);
        return out;
    }

    public String readCollectedOrderDetail(int orderId) throws IOException {
        Path p = StorageLocation.collectedPath.resolve(orderId + ".txt");
        if (!Files.exists(p)) throw new IOException("Collected order file not found: " + p);
        return String.join("\n", Files.readAllLines(p, StandardCharsets.UTF_8));
    }

    // ---------- helpers ----------

    private void ensureOrderFoldersExist() throws IOException {
        if (Files.notExists(StorageLocation.ordersPath)) Files.createDirectories(StorageLocation.ordersPath);
        if (Files.notExists(StorageLocation.orderedPath)) Files.createDirectories(StorageLocation.orderedPath);
        if (Files.notExists(StorageLocation.progressingPath)) Files.createDirectories(StorageLocation.progressingPath);
        if (Files.notExists(StorageLocation.collectedPath)) Files.createDirectories(StorageLocation.collectedPath);
    }

    private int countTxtFiles(Path dir) throws IOException {
        try (Stream<Path> s = Files.list(dir)) {
            return (int) s.filter(p -> p.getFileName().toString().endsWith(".txt")).count();
        }
    }

    public static double sumCollectedSales(Path collectedDir) throws IOException {
        double total = 0.0;
        try (Stream<Path> s = Files.list(collectedDir)) {
            for (Path p : s.filter(x -> x.getFileName().toString().endsWith(".txt")).collect(Collectors.toList())) {
                total += extractTotalPrice(p);
            }
        }
        return total;
    }

    public static double extractTotalPrice(Path orderFile) throws IOException {
        List<String> lines = Files.readAllLines(orderFile, StandardCharsets.UTF_8);
        for (String line : lines) {
            Matcher m = TOTAL_PRICE_PATTERN.matcher(line.trim());
            if (m.matches()) {
                try {
                    return new BigDecimal(m.group(1)).doubleValue();
                } catch (NumberFormatException ignore) {
                    return 0.0;
                }
            }
        }
        return 0.0;
    }

    private List<String> listRecentCollected(Path collectedDir, int limit) throws IOException {
        try (Stream<Path> s = Files.list(collectedDir)) {
            return s.filter(p -> p.getFileName().toString().endsWith(".txt"))
                    .sorted((a, b) -> {
                        try {
                            return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a));
                        } catch (IOException e) {
                            return 0;
                        }
                    })
                    .limit(limit)
                    .map(p -> p.getFileName().toString())
                    .collect(Collectors.toList());
        }
    }

    public static Integer tryParseLeadingInt(String s) {
        if (s == null) return null;
        String trimmed = s.trim();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (Character.isDigit(c)) sb.append(c);
            else break;
        }
        if (sb.length() == 0) return null;
        try {
            return Integer.parseInt(sb.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}