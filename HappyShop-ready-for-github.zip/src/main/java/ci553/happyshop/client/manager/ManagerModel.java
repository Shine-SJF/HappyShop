package ci553.happyshop.client.manager;

import ci553.happyshop.utility.StorageLocation;
import javafx.application.Platform;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

/**
 * Manager client Model.
 *
 * Uses {@link ManagerReportService} to compute stats from order files and to export reports.
 */
public class ManagerModel {

    public ManagerView view;

    private final ManagerReportService reportService = new ManagerReportService();

    // last loaded stats (for exporting without re-scan if desired)
    private ManagerStats lastStats;

    public void refreshStats() {
        try {
            lastStats = reportService.computeStats();
            view.setStats(lastStats);
            view.log("Refreshed stats.");
        } catch (IOException e) {
            view.log("ERROR refreshing stats: " + e.getMessage());
        }
    }

    public void exportReport() {
        try {
            if (lastStats == null) lastStats = reportService.computeStats();

            Path reportsDir = StorageLocation.ordersPath.resolve("reports");
            if (Files.notExists(reportsDir)) Files.createDirectories(reportsDir);

            Path out = reportService.exportCsvReport(lastStats, reportsDir);
            view.log("Exported report: " + out.toString());
        } catch (IOException e) {
            view.log("ERROR exporting report: " + e.getMessage());
        }
    }

    public void shutdownSystem() {
        view.log("Shutdown requested at " + LocalDateTime.now() + " (graceful).");
        // Close all JavaFX stages and end application
        Platform.exit();
        // Platform.exit() should be enough; System.exit is a fallback for safety in case of non-daemon threads.
        System.exit(0);
    }

    public void showSelectedCollectedDetail() {
        String row = view.getSelectedCollectedRow();
        if (row == null) return;

        Integer orderId = ManagerReportService.tryParseLeadingInt(row);
        if (orderId == null) return;

        try {
            String detail = reportService.readCollectedOrderDetail(orderId);
            view.log("Collected order " + orderId + " details:");
            view.log(detail);
        } catch (IOException e) {
            view.log("ERROR reading order " + orderId + ": " + e.getMessage());
        }
    }
}