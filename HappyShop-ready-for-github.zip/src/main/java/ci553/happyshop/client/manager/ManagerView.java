package ci553.happyshop.client.manager;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Manager client GUI (MVC View).
 *
 * Provides high-level system controls and reporting:
 *  - Live order counts by state (Ordered / Progressing / Collected)
 *  - Sales total computed from collected order files
 *  - Export report to CSV
 *  - Graceful shutdown (closes all JavaFX windows)
 */
public class ManagerView {

    // MVC link
    public ManagerController controller;

    // UI controls
    public Button btnRefresh = new Button("Refresh");
    public Button btnExport = new Button("Export CSV report");
    public Button btnShutdown = new Button("Shutdown system");

    public Label lbOrdered = new Label("Ordered: -");
    public Label lbProgressing = new Label("Progressing: -");
    public Label lbCollected = new Label("Collected: -");
    public Label lbSalesTotal = new Label("Total sales: -");
    public Label lbLastUpdated = new Label("Last updated: -");

    public ListView<String> lvRecentCollected = new ListView<>();
    public TextArea taLog = new TextArea();

    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.UK);

    public void start(Stage stage) {
        stage.setTitle("HappyShop : Manager");

        // Left: actions
        VBox left = new VBox(10, btnRefresh, btnExport, btnShutdown);
        left.setPadding(new Insets(12));
        left.setAlignment(Pos.TOP_LEFT);
        left.setPrefWidth(180);

        btnShutdown.setStyle("-fx-background-color: #c62828; -fx-text-fill: white;");

        // Center: stats
        VBox stats = new VBox(8,
                new Label("Order status summary"),
                lbOrdered, lbProgressing, lbCollected,
                new Separator(),
                new Label("Sales summary"),
                lbSalesTotal,
                new Separator(),
                lbLastUpdated
        );
        stats.setPadding(new Insets(12));

        // Right: recent collected list
        VBox right = new VBox(8, new Label("Recently collected orders (latest first)"), lvRecentCollected);
        right.setPadding(new Insets(12));
        right.setPrefWidth(320);

        // Bottom: log output
        taLog.setEditable(false);
        taLog.setPrefRowCount(6);
        VBox bottom = new VBox(6, new Label("Manager log"), taLog);
        bottom.setPadding(new Insets(12));

        BorderPane root = new BorderPane();
        root.setLeft(left);
        root.setCenter(stats);
        root.setRight(right);
        root.setBottom(bottom);

        // Wire events to controller actions
        btnRefresh.setOnAction(e -> controller.handle("Refresh"));
        btnExport.setOnAction(e -> controller.handle("Export"));
        btnShutdown.setOnAction(e -> controller.handle("Shutdown"));

        lvRecentCollected.getSelectionModel().selectedItemProperty().addListener((obs, oldV, newV) -> {
            if (newV != null) controller.handle("SelectCollected");
        });

        stage.setScene(new Scene(root, 920, 520));
        stage.show();
    }

    public void setStats(ManagerStats stats) {
        lbOrdered.setText("Ordered: " + stats.orderedCount());
        lbProgressing.setText("Progressing: " + stats.progressingCount());
        lbCollected.setText("Collected: " + stats.collectedCount());
        lbSalesTotal.setText("Total sales: " + currencyFormat.format(stats.totalSales()));
        lbLastUpdated.setText("Last updated: " + stats.lastUpdated());
        lvRecentCollected.getItems().setAll(stats.recentCollectedOrderIds());
    }

    public void log(String message) {
        taLog.appendText(message + System.lineSeparator());
    }

    public String getSelectedCollectedRow() {
        return lvRecentCollected.getSelectionModel().getSelectedItem();
    }
}