package ci553.happyshop.client.manager;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Snapshot of manager-relevant system stats.
 */
public record ManagerStats(
        int orderedCount,
        int progressingCount,
        int collectedCount,
        double totalSales,
        LocalDateTime lastUpdated,
        List<String> recentCollectedOrderIds
) { }