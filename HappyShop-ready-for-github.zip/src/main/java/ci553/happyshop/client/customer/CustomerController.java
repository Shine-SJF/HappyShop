package ci553.happyshop.client.customer;

import java.io.IOException;
import java.sql.SQLException;

public class CustomerController {
    public CustomerModel cusModel;

    public void doAction(String action) throws SQLException, IOException {
        switch (action) {
            case "Search":
                cusModel.search();
                break;
            case "Add to Trolley":
                cusModel.addToTrolley();
                break;
            case "Select":
                cusModel.selectProduct();
                break;
            case "Cancel":
                cusModel.cancel();
                break;
            case "Check Out":
                cusModel.checkOut();
                break;
            case "OK & Close":
                cusModel.closeReceipt();
                break;
            case "Order History":
            case "Refresh History":
                cusModel.loadOrderHistory();
                break;
            case "View Order":
                cusModel.viewSelectedOrderFromHistory();
                break;
            case "Back to Trolley":
                // View handles switching; no model change needed
                break;
        }
    }

}
