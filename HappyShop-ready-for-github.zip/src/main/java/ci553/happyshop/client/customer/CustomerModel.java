package ci553.happyshop.client.customer;

import ci553.happyshop.catalogue.Order;
import ci553.happyshop.catalogue.Product;
import ci553.happyshop.storageAccess.DatabaseRW;
import ci553.happyshop.orderManagement.OrderHub;
import ci553.happyshop.orderManagement.OrderHistoryLookup;
import ci553.happyshop.utility.StorageLocation;
import ci553.happyshop.utility.ProductListFormatter;
import ci553.happyshop.storageAccess.CustomerOrderHistoryStore;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 * You can either directly modify the CustomerModel class to implement the required tasks,
 * or create a subclass of CustomerModel and override specific methods where appropriate.
 */
public class CustomerModel {
    public CustomerView cusView;
    public DatabaseRW databaseRW; //Interface type, not specific implementation
                                  //Benefits: Flexibility: Easily change the database implementation.

    private Product theProduct =null; // product found from search
    private ArrayList<Product> searchResults = new ArrayList<>(); // list of products found from search
    private ArrayList<Product> trolley =  new ArrayList<>(); // a list of products in trolley

    // Customer order history persistence (simple file: one orderId per line)
    private final CustomerOrderHistoryStore historyStore = new CustomerOrderHistoryStore();

    // Persistent order history for the Customer client
    private final CustomerOrderHistoryStore orderHistoryStore = new CustomerOrderHistoryStore();

    // Four UI elements to be passed to CustomerView for display updates.
    private String imageName = "imageHolder.jpg";                // Image to show in product preview (Search Page)
    private String displayLaSearchResult = "No Product was searched yet"; // Label showing search result message (Search Page)
    private String displayTaTrolley = "";                                // Text area content showing current trolley items (Trolley Page)
    private String displayTaReceipt = "";                                // Text area content showing receipt after checkout (Receipt Page)

    //SELECT productID, description, image, unitPrice,inStock quantity
    void search() throws SQLException {
        // Build a keyword from the two text fields (ID takes priority)
        String keyword = cusView.tfId.getText().trim();
        if (keyword.isEmpty()) {
            keyword = cusView.tfName.getText().trim();
        }

        // Pull matches from the database (supports ID or description keyword)
        if (!keyword.isEmpty()) {
            searchResults = databaseRW.searchProduct(keyword);
        } else {
            searchResults.clear();
        }

        // Apply optional filters
        boolean inStockOnly = cusView.cbInStockOnly != null && cusView.cbInStockOnly.isSelected();

        String maxPriceText = (cusView.tfMaxPrice == null) ? "" : cusView.tfMaxPrice.getText().trim();
        Double maxPrice = null;
        if (!maxPriceText.isEmpty()) {
            try {
                maxPrice = Double.parseDouble(maxPriceText);
            } catch (NumberFormatException ignored) {
                // Keep maxPrice null; show message in summary below.
            }
        }

        ArrayList<Product> filtered = new ArrayList<>();
        for (Product p : searchResults) {
            if (inStockOnly && p.getStockQuantity() <= 0) continue;
            if (maxPrice != null && p.getUnitPrice() > maxPrice) continue;
            filtered.add(p);
        }

        // Sort
        String sortMode = (cusView.cbSort == null || cusView.cbSort.getValue() == null)
                ? "Sort: ID" : cusView.cbSort.getValue();

        if (sortMode.contains("Price (low")) {
            filtered.sort(Comparator.comparingDouble(Product::getUnitPrice));
        } else if (sortMode.contains("Price (high")) {
            filtered.sort(Comparator.comparingDouble(Product::getUnitPrice).reversed());
        } else {
            filtered.sort(Comparator.comparing(Product::getProductId));
        }

        // Push list to the view
        cusView.updateObservableProductList(filtered);

        // Update summary + preview prompt
        String summary;
        if (keyword.isEmpty()) {
            summary = "Type an ID or keyword, then Search.";
        } else if (!maxPriceText.isEmpty() && maxPrice == null) {
            summary = String.format("Found %d results for '%s' (max price ignored: '%s' is not a number).",
                    filtered.size(), keyword, maxPriceText);
        } else {
            summary = String.format("Found %d results for '%s'.", filtered.size(), keyword);
        }
        cusView.updateSearchSummary(summary);

        theProduct = null;
        imageName = "imageHolder.jpg";
        displayLaSearchResult = "Select a product from the list to preview it.";
        updateView();
    }


    void selectProduct() {
        Product selected = cusView.lvProducts.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        theProduct = selected;

        // Build preview text (similar to the old single-result UI)
        String productId = selected.getProductId();
        double unitPrice = selected.getUnitPrice();
        String description = selected.getProductDescription();
        int stock = selected.getStockQuantity();

        String baseInfo = String.format("Product_Id: %s\n%s,\nPrice: £%.2f", productId, description, unitPrice);
        String quantityInfo = stock < 100 ? String.format("\n%d units left.", stock) : "";
        displayLaSearchResult = baseInfo + quantityInfo;

        // Update preview image path
        String relativeImageUrl = StorageLocation.imageFolder + selected.getProductImageName();
        Path imageFullPath = Paths.get(relativeImageUrl).toAbsolutePath();
        imageName = imageFullPath.toUri().toString();

        updateView();
    }

    void addToTrolley(){
        if(theProduct!= null){

            // trolley.add(theProduct) — Product is appended to the end of the trolley.
            // To keep the trolley organized, add code here or call a method that:
            //TODO
            // 1. Merges items with the same product ID (combining their quantities).
            // 2. Sorts the products in the trolley by product ID.
            trolley.add(theProduct);
            displayTaTrolley = ProductListFormatter.buildString(trolley); //build a String for trolley so that we can show it
        }
        else{
            displayLaSearchResult = "Please search for an available product before adding it to the trolley";
            System.out.println("must search and get an available product before add to trolley");
        }
        displayTaReceipt=""; // Clear receipt to switch back to trolleyPage (receipt shows only when not empty)
        updateView();
    }

    void checkOut() throws IOException, SQLException {
        if(!trolley.isEmpty()){
            // Group the products in the trolley by productId to optimize stock checking
            // Check the database for sufficient stock for all products in the trolley.
            // If any products are insufficient, the update will be rolled back.
            // If all products are sufficient, the database will be updated, and insufficientProducts will be empty.
            // Note: If the trolley is already organized (merged and sorted), grouping is unnecessary.
            ArrayList<Product> groupedTrolley= groupProductsById(trolley);
            ArrayList<Product> insufficientProducts= databaseRW.purchaseStocks(groupedTrolley);

            if(insufficientProducts.isEmpty()){ // If stock is sufficient for all products
                //get OrderHub and tell it to make a new Order
                OrderHub orderHub =OrderHub.getOrderHub();
                Order theOrder = orderHub.newOrder(trolley);

                // --- Order history extension ---
                // Persist the order id so the customer can view it later (even after restart).
                try {
                    historyStore.appendOrderId(theOrder.getOrderId());
                } catch (IOException e) {
                    // Non-fatal: checkout succeeded, but history write failed.
                    System.err.println("Failed to write order history: " + e.getMessage());
                }

                trolley.clear();
                displayTaTrolley ="";
                displayTaReceipt = String.format(
                        "Order_ID: %s\nOrdered_Date_Time: %s\n%s",
                        theOrder.getOrderId(),
                        theOrder.getOrderedDateTime(),
                        ProductListFormatter.buildString(theOrder.getProductList())
                );
                System.out.println(displayTaReceipt);
            }
            else{ // Some products have insufficient stock — build an error message to inform the customer
                StringBuilder errorMsg = new StringBuilder();
                for(Product p : insufficientProducts){
                    errorMsg.append("\u2022 "+ p.getProductId()).append(", ")
                            .append(p.getProductDescription()).append(" (Only ")
                            .append(p.getStockQuantity()).append(" available, ")
                            .append(p.getOrderedQuantity()).append(" requested)\n");
                }
                theProduct=null;

                //TODO
                // Add the following logic here:
                // 1. Remove products with insufficient stock from the trolley.
                // 2. Trigger a message window to notify the customer about the insufficient stock, rather than directly changing displayLaSearchResult.
                //You can use the provided RemoveProductNotifier class and its showRemovalMsg method for this purpose.
                //remember close the message window where appropriate (using method closeNotifierWindow() of RemoveProductNotifier class)
                displayLaSearchResult = "Checkout failed due to insufficient stock for the following products:\n" + errorMsg.toString();
                System.out.println("stock is not enough");
            }
        }
        else{
            displayTaTrolley = "Your trolley is empty";
            System.out.println("Your trolley is empty");
        }
        updateView();
    }
    /**
     * Groups products by their productId to optimize database queries and updates.
     * By grouping products, we can check the stock for a given `productId` once, rather than repeatedly
     */
    private ArrayList<Product> groupProductsById(ArrayList<Product> proList) {
        Map<String, Product> grouped = new HashMap<>();
        for (Product p : proList) {
            String id = p.getProductId();
            if (grouped.containsKey(id)) {
                Product existing = grouped.get(id);
                existing.setOrderedQuantity(existing.getOrderedQuantity() + p.getOrderedQuantity());
            } else {
                // Make a shallow copy to avoid modifying the original
                grouped.put(id,new Product(p.getProductId(),p.getProductDescription(),
                        p.getProductImageName(),p.getUnitPrice(),p.getStockQuantity()));
            }
        }
        return new ArrayList<>(grouped.values());
    }

    void cancel(){
        trolley.clear();
        displayTaTrolley="";
        updateView();
    }
    void closeReceipt(){
        displayTaReceipt="";
    }

    // --- Order History extension ---
    void loadOrderHistory() {
        try {
            java.util.List<Integer> ids = historyStore.loadOrderIds(true);
            java.util.List<String> strings = new java.util.ArrayList<>();
            for (Integer id : ids) {
                OrderHistoryLookup.LocatedState state = OrderHistoryLookup.locateState(id);
                strings.add(id + "  (" + state + ")");
            }

            String msg = ids.isEmpty()
                    ? "No previous orders yet. Place an order to see it here."
                    : "Showing " + ids.size() + " previous order(s). Select one to view details.";

            cusView.updateOrderHistoryList(strings, msg);
            cusView.showOrderHistoryPage();
        } catch (IOException e) {
            cusView.updateOrderHistoryList(java.util.List.of(), "Could not read history: " + e.getMessage());
            cusView.showOrderHistoryPage();
        }
    }

    void viewSelectedOrderFromHistory() {
        String selected = (cusView.lvOrderHistory == null)
                ? null
                : cusView.lvOrderHistory.getSelectionModel().getSelectedItem();
        if (selected == null || selected.trim().isEmpty()) {
            cusView.updateOrderHistoryDetails("Select an order from the list.");
            return;
        }

        // selected line format: "12  (Ordered)" -> extract leading number
        String idPart = selected.trim().split("\\s+")[0];
        int orderId;
        try {
            orderId = Integer.parseInt(idPart);
        } catch (NumberFormatException e) {
            cusView.updateOrderHistoryDetails("Invalid order id: " + idPart);
            return;
        }

        try {
            OrderHistoryLookup.LocatedOrder order = OrderHistoryLookup.readOrder(orderId);
            String header = "State: " + order.state + System.lineSeparator() + System.lineSeparator();
            cusView.updateOrderHistoryDetails(header + order.details);
        } catch (IOException e) {
            cusView.updateOrderHistoryDetails("Could not read order " + orderId + ": " + e.getMessage());
        }
    }

    void updateView() {
        if(theProduct != null){
            imageName = theProduct.getProductImageName();
            String relativeImageUrl = StorageLocation.imageFolder +imageName; //relative file path, eg images/0001.jpg
            // Get the full absolute path to the image
            Path imageFullPath = Paths.get(relativeImageUrl).toAbsolutePath();
            imageName = imageFullPath.toUri().toString(); //get the image full Uri then convert to String
            System.out.println("Image absolute path: " + imageFullPath); // Debugging to ensure path is correct
        }
        else{
            imageName = "imageHolder.jpg";
        }
        cusView.update(imageName, displayLaSearchResult, displayTaTrolley,displayTaReceipt);
    }
     // extra notes:
     //Path.toUri(): Converts a Path object (a file or a directory path) to a URI object.
     //File.toURI(): Converts a File object (a file on the filesystem) to a URI object

    //for test only
    public ArrayList<Product> getTrolley() {
        return trolley;
    }
}
