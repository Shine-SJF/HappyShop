package ci553.happyshop.storageAccess;

import ci553.happyshop.utility.StorageLocation;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Persists a simple list of order IDs for the Customer client.
 *
 * Storage format (one order id per line):
 * 12
 * 13
 * 14
 */
public class CustomerOrderHistoryStore {

    private final Path historyFile;

    public CustomerOrderHistoryStore() {
        this(StorageLocation.customerHistoryFilePath);
    }

    public CustomerOrderHistoryStore(Path historyFile) {
        this.historyFile = historyFile;
    }

    /** Ensure the history folder + file exist. */
    private void ensureExists() throws IOException {
        Path folder = historyFile.getParent();
        if (folder != null && Files.notExists(folder)) {
            Files.createDirectories(folder);
        }
        if (Files.notExists(historyFile)) {
            Files.writeString(historyFile, "", StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        }
    }

    /**
     * Append an order id (if it's not already present).
     */
    public void appendOrderId(int orderId) throws IOException {
        ensureExists();
        List<Integer> existing = loadOrderIds(false);
        if (existing.contains(orderId)) return;

        Files.writeString(
                historyFile,
                orderId + System.lineSeparator(),
                StandardCharsets.UTF_8,
                StandardOpenOption.APPEND
        );
    }

    /**
     * Load order IDs.
     *
     * @param newestFirst when true, returns most recent IDs first.
     */
    public List<Integer> loadOrderIds(boolean newestFirst) throws IOException {
        ensureExists();
        List<String> lines = Files.readAllLines(historyFile, StandardCharsets.UTF_8);
        ArrayList<Integer> ids = new ArrayList<>();
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            try {
                ids.add(Integer.parseInt(trimmed));
            } catch (NumberFormatException ignored) {
                // Ignore malformed lines.
            }
        }
        if (newestFirst) {
            Collections.reverse(ids);
        }
        return ids;
    }
}
