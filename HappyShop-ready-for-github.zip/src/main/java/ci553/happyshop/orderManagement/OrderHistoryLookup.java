package ci553.happyshop.orderManagement;

import ci553.happyshop.storageAccess.OrderFileManager;
import ci553.happyshop.utility.StorageLocation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Helper service to locate and read an order file (by ID) regardless of its state folder.
 *
 * This is used by the Customer client to implement "Order History" / "Track an order".
 */
public class OrderHistoryLookup {

    public enum LocatedState {
        Ordered,
        Progressing,
        Collected,
        NotFound
    }

    public static class LocatedOrder {
        public final LocatedState state;
        public final Path filePath;
        public final String details;

        public LocatedOrder(LocatedState state, Path filePath, String details) {
            this.state = state;
            this.filePath = filePath;
            this.details = details;
        }
    }

    /**
     * Find the order file in ordered/progressing/collected folders.
     */
    public static LocatedState locateState(int orderId) {
        Path ordered = StorageLocation.orderedPath.resolve(orderId + ".txt");
        if (Files.exists(ordered)) return LocatedState.Ordered;

        Path progressing = StorageLocation.progressingPath.resolve(orderId + ".txt");
        if (Files.exists(progressing)) return LocatedState.Progressing;

        Path collected = StorageLocation.collectedPath.resolve(orderId + ".txt");
        if (Files.exists(collected)) return LocatedState.Collected;

        return LocatedState.NotFound;
    }

    /**
     * Read the order file and return state + details.
     */
    public static LocatedOrder readOrder(int orderId) throws IOException {
        LocatedState state = locateState(orderId);
        if (state == LocatedState.NotFound) {
            return new LocatedOrder(state, null, "Order " + orderId + " not found.");
        }

        Path dir;
        switch (state) {
            case Ordered:
                dir = StorageLocation.orderedPath;
                break;
            case Progressing:
                dir = StorageLocation.progressingPath;
                break;
            case Collected:
                dir = StorageLocation.collectedPath;
                break;
            default:
                dir = null;
        }

        String details = OrderFileManager.readOrderFile(dir, orderId);
        Path filePath = dir.resolve(orderId + ".txt");
        return new LocatedOrder(state, filePath, details);
    }
}
