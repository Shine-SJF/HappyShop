package ci553.happyshop.client.manager;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class ManagerReportServiceTest {

    @TempDir
    Path tempDir;

    @Test
    void extractTotalPrice_readsTotalPriceLine() throws IOException {
        Path f = tempDir.resolve("12.txt");
        Files.writeString(f,
                "OrderId: 12\n" +
                "State: Collected\n" +
                "Items:\n" +
                "0001 apples  x2 (£3.00)\n" +
                "Total price: £1002.99\n",
                StandardCharsets.UTF_8
        );

        double total = ManagerReportService.extractTotalPrice(f);
        assertEquals(1002.99, total, 0.0001);
    }

    @Test
    void sumCollectedSales_sumsAcrossFiles() throws IOException {
        Path a = tempDir.resolve("1.txt");
        Path b = tempDir.resolve("2.txt");
        Files.writeString(a, "Total price: £10.00\n", StandardCharsets.UTF_8);
        Files.writeString(b, "Total price: £2.50\n", StandardCharsets.UTF_8);

        double total = ManagerReportService.sumCollectedSales(tempDir);
        assertEquals(12.50, total, 0.0001);
    }
}